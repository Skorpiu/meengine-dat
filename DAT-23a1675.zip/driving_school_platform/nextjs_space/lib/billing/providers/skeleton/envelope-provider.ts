import type { BillingProvider } from "@/lib/billing/provider";
import type {
  BillingCheckoutRequest,
  BillingCheckoutResponse,
  BillingEvent,
  BillingEventType,
  BillingPlanKey,
  BillingProviderId,
  BillingSubscriptionStatus,
  BillingWebhookInput,
  BillingWebhookParseResult,
} from "@/lib/billing/types";

type EnvelopeBody = {
  providerEventId?: unknown;
  eventType?: unknown;
  organizationId?: unknown;
  payload?: unknown;
};

function isBillingEventType(x: unknown): x is BillingEventType {
  return (
    x === "CHECKOUT_SESSION_CREATED" ||
    x === "PAYMENT_SUCCEEDED" ||
    x === "PAYMENT_FAILED" ||
    x === "SUBSCRIPTION_STARTED" ||
    x === "SUBSCRIPTION_RENEWED" ||
    x === "SUBSCRIPTION_CANCELLED" ||
    x === "SUBSCRIPTION_EXPIRED" ||
    x === "REFUND_ISSUED"
  );
}

function pickProviderEventId(input: BillingWebhookInput): string | null {
  return (
    input.headers["x-provider-event-id"] ?? input.headers["x-event-id"] ?? null
  );
}

function tryParseEnvelope(raw: string): EnvelopeBody | null {
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== "object") return null;
    return parsed as EnvelopeBody;
  } catch {
    return null;
  }
}

function asObject(x: unknown): Record<string, unknown> | null {
  if (!x || typeof x !== "object") return null;
  return x as Record<string, unknown>;
}

function isSubscriptionStatus(x: unknown): x is BillingSubscriptionStatus {
  return (
    x === "ACTIVE" ||
    x === "TRIAL" ||
    x === "PAST_DUE" ||
    x === "SUSPENDED" ||
    x === "CANCELLED" ||
    x === "EXPIRED"
  );
}

function isPlanKey(x: unknown): x is BillingPlanKey {
  return x === "BASE" || x === "PREMIUM" || x === "ENTERPRISE";
}

function toDateOrNull(x: unknown): Date | null {
  if (x === null) return null;
  if (x instanceof Date) return x;
  if (typeof x === "string") {
    const ms = Date.parse(x);
    if (!Number.isNaN(ms)) return new Date(ms);
  }
  return null;
}

function assertOptionalDateField(
  subObj: Record<string, unknown>,
  field: string,
): void {
  if (!(field in subObj)) return; // absent is allowed
  const v = subObj[field];
  if (v === null) return;
  if (v instanceof Date) return;
  if (typeof v === "string" && !Number.isNaN(Date.parse(v))) return;
  throw new Error(`Invalid subscription field: ${field}`);
}

function assertOptionalEnumField(
  subObj: Record<string, unknown>,
  field: "status" | "planKey",
): void {
  if (!(field in subObj)) return; // absent is allowed
  const v = subObj[field];
  if (typeof v !== "string") {
    throw new Error(`Invalid subscription field: ${field}`);
  }
  if (field === "status" && !isSubscriptionStatus(v)) {
    throw new Error(`Invalid subscription field: ${field}`);
  }
  if (field === "planKey" && !isPlanKey(v)) {
    throw new Error(`Invalid subscription field: ${field}`);
  }
}

function tryParseSubscriptionFromRawPayload(
  rawPayload: unknown,
): BillingEvent["subscription"] | null {
  const root = asObject(rawPayload);
  const subObj = root ? asObject(root.subscription) : null;
  if (!subObj) return null;

  // Adapter policy: if a field is present but invalid, fail deterministically.
  // Missing optional fields remain allowed for backwards compatibility.
  assertOptionalEnumField(subObj, "status");
  assertOptionalEnumField(subObj, "planKey");
  assertOptionalDateField(subObj, "currentPeriodStartIso");
  assertOptionalDateField(subObj, "currentPeriodEndIso");
  assertOptionalDateField(subObj, "currentPeriodStart");
  assertOptionalDateField(subObj, "currentPeriodEnd");

  const externalId =
    typeof subObj.externalId === "string" ? subObj.externalId : null;
  const status = isSubscriptionStatus(subObj.status) ? subObj.status : null;
  const planKey = isPlanKey(subObj.planKey) ? subObj.planKey : null;

  const currentPeriodStart =
    toDateOrNull(subObj.currentPeriodStartIso) ??
    toDateOrNull(subObj.currentPeriodStart);
  const currentPeriodEnd =
    toDateOrNull(subObj.currentPeriodEndIso) ??
    toDateOrNull(subObj.currentPeriodEnd);

  if (
    !externalId &&
    !status &&
    !planKey &&
    !currentPeriodStart &&
    !currentPeriodEnd
  ) {
    return null;
  }

  return {
    externalId,
    status,
    planKey,
    currentPeriodStart,
    currentPeriodEnd,
  };
}

export function createEnvelopeBillingProvider(
  id: Exclude<BillingProviderId, "sibs">,
): BillingProvider {
  return {
    id,

    async createCheckout(
      req: BillingCheckoutRequest,
    ): Promise<BillingCheckoutResponse> {
      const checkoutExternalId = `${id}_co_stub_${req.organizationId}_${req.planKey}`;
      return {
        provider: id,
        redirectUrl: `https://checkout.${id}.invalid/session/${encodeURIComponent(
          checkoutExternalId,
        )}`,
        checkoutExternalId,
      };
    },

    async parseWebhook(
      input: BillingWebhookInput,
    ): Promise<BillingWebhookParseResult> {
      const envelope = tryParseEnvelope(input.body);
      const fromBody =
        envelope?.providerEventId &&
        typeof envelope.providerEventId === "string"
          ? envelope.providerEventId
          : null;
      const providerEventId = fromBody ?? pickProviderEventId(input);
      if (!providerEventId) return { events: [] };

      const type: BillingEventType = isBillingEventType(envelope?.eventType)
        ? (envelope!.eventType as BillingEventType)
        : "CHECKOUT_SESSION_CREATED";

      const organizationId =
        typeof envelope?.organizationId === "string"
          ? envelope.organizationId
          : null;

      const rawPayload =
        typeof envelope?.payload !== "undefined"
          ? envelope.payload
          : (envelope ?? input.body);

      const event: BillingEvent = {
        provider: id,
        providerEventId,
        type,
        occurredAt: new Date(0),
        organizationId,
        subscription: tryParseSubscriptionFromRawPayload(rawPayload),
        payment: null,
        raw: {
          headers: input.headers,
          body: input.body,
          parsed: envelope,
          payload: rawPayload,
        },
      };

      return { events: [event] };
    },
  };
}
